# -*- coding: utf-8 -*-
"""
Created on Fri May  9 20:56:02 2025

@author: USER
"""

import numpy as np
import pickle

# Load your trained traffic accident prediction model
def load_model():
    with open("C:/Users/USER/Documents/Deploying machine learning/traffic_accident_model.pkl", "rb") as f:
        return pickle.load(f)

model = load_model()
print("✅ Model loaded successfully.")

model = load_model()
print(model.feature_names_in_)  # Only works if you used a plain RandomForestClassifier



# Provide all 28 numeric feature values used during training (example dummy values)
# Replace these with real values in correct order
input_data = (
    1, 0, 2, 1, 0, 3, 1, 0, 1, 0,
    0, 1, 0, 1, 0, 0, 1, 1, 0, 1,
    0, 1, 0, 1, 1, 0, 0, 1  # 28 values
)

# Convert to numpy array and reshape
input_data_np = np.asarray(input_data).reshape(1, -1)

# Predict
prediction = model.predict(input_data_np)

# Show result
print("🔎 Prediction result:", prediction[0])
if prediction[0] == 0:
    print("🟢 Predicted Severity: Low")
elif prediction[0] == 1:
    print("🟡 Predicted Severity: Medium")
else:
    print("🔴 Predicted Severity: High")