# -*- coding: utf-8 -*-
"""
Created on Sat May 10 11:53:02 2025

@author: USER
"""
import streamlit as st
import numpy as np
import pickle
from sklearn.preprocessing import LabelEncoder

# Load model
def load_model():
    with open(r"C:/Users/USER/Documents/Deploying machine learning/traffic_accident_model.pkl", "rb") as f:
        return pickle.load(f)


model = load_model()


st.success("✅ Model loaded successfully.")

def accident_prediction(input_data):

# Input fields
    status = st.selectbox("Status", ["Unvalidated", "Validated", "Completed"])
    collision_year = st.number_input("Collision Year", min_value=2000, max_value=2030, value=2023)
    police_force = st.number_input("Police Force Code", min_value=1, max_value=100, value=10)
    legacy_collision_severity = st.selectbox("Collision Severity", ["Slight", "Serious", "Fatal"])
    
    # Encode categorical variables
    label_encoder = LabelEncoder()
    status_encoded = label_encoder.fit_transform([status])[0]
    severity_encoded = label_encoder.fit_transform([legacy_collision_severity])[0]
    
    # Prepare input (example — replace with correct features in correct order)
    input_data_np = np.array([[status_encoded, collision_year, police_force, severity_encoded]])
    
    # Predict
    if st.button("Predict Severity"):
        prediction = model.predict(input_data_np)
        st.write("🔎 Prediction:", prediction[0])
        if prediction[0] == 0:
            print("🟢 Predicted Severity: Low")
        elif prediction[0] == 1:
            print("🟡 Predicted Severity: Medium")
        else:
            print("🔴 Predicted Severity: High")
        
        
def main():
    
    
    
    
    #giving a title
    st.title('Accident Prediction Web APP')
    
    
    
    
    #getting the input data from from the user
    status=st.text_input('Status')
    collision_year=st.text_input('Collision Year')
    police_force=st.text_input('Police force')
    legacy_collision_severity=st.text_input('Legacy Collision Severity')
    number_of_vehicles=st.text_input('Number of Vehicles')
    number_of_casualties=st.text_input('Number of Casualties')
    day_of_week=st.text_input('Day of Week')
    local_authority_district=st.text_input('Local Authority District')
    local_authority_ons_district=st.text_input('Local Authority ons District')
    local_authority_highway=st.text_input('Local Authority Highway')
    first_road_class=st.text_input('First Road Class')
    first_road_number=st.text_input('First Road Number')
    road_type=st.text_input('Road Type')
    speed_limit=st.text_input('Speed Limit')
    junction_detail=st.text_input('Junction Detail')
    junction_control=st.text_input('Junction Control')
    second_road_class=st.text_input('Second Road Class')
    second_road_number=st.text_input('Second Road Number')
    pedestrian_crossing_human_control=st.text_input('Pedestrian Crossing Human Control')
    pedestrian_crossing_physical_facilities=st.text_input('Pedestrian Crossing Physical Facilities')
    light_conditions=st.text_input('Light Conditions')
    weather_conditions=st.text_input('Weather Conditions')
    road_surface_conditions=st.text_input('road_surface_conditions')
    special_conditions_at_site=st.text_input('Special Conditions at Site')
    carriageway_hazards=st.text_input('Carriageway Hazards')
    urban_or_rural_area=st.text_input('Urban or Rural Area')
    did_police_officer_attend_scene_of_collision=st.text_input('Did Police Officer Attend Scene of Collision?')
    trunk_road_flag=st.text_input('Trunk Road Flag')

    #code for prediction
    analysis= ''
    
    #creating a button for prediction
    
    if st.button('Accident Prediction Result'):
        analysis = accident_prediction([status,collision_year,police_force,legacy_collision_severity
                 ,number_of_vehicles,number_of_casualties,day_of_week
                 ,local_authority_district,local_authority_ons_district
                 ,local_authority_highway,first_road_class,first_road_number
                 ,road_type,speed_limit,junction_detail,junction_control
                 ,second_road_class,second_road_number
                 ,pedestrian_crossing_human_control
                 ,pedestrian_crossing_physical_facilities,light_conditions
                 ,weather_conditions,road_surface_conditions
                 ,special_conditions_at_site,carriageway_hazards,urban_or_rural_area
                 ,did_police_officer_attend_scene_of_collision,trunk_road_flag])
    
    
    st.success(analysis)
    
    
    
if __name__ == '__main__':
    main() 

